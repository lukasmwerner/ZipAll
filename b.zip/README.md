# ZipAdd

A CLI tool to add files to zips or just to say specific files to add to the zip

Usage:

```bash
$ zipadd Archive.zip file1 file2 file3
```
